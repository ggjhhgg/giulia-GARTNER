# README

Order Reference: 2022-12-25-ff4d935
Licensee: ngoc
E-mail: bangocqd123@gmail.com

## Fonts included:
* Roslindale Series

Your purchase entitles you to use the fonts according to the following limitations:

### Testing License

* 1 desktop workstation, for testing purposes only
* 0 monthly unique web visitors, for testing purposes only
* 0 apps or e-books, for testing purposes only

            
Please refer to LICENSE.txt for the full terms of the license. If you would like to exceed any of these limitations, you can purchase an upgrade (and pay only the difference in price) by contacting me at david@djr.com.

## Using the fonts

Please refer to INSTALL.txt for desktop installation instructions and font cache troubleshooting.

For an example of how to use the web font files via CSS @font-face, please consult the CSS file included in the web fonts folder.

Happy typesetting!

- DJR